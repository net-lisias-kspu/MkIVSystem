============================
MkIV Spaceplane Parts v1.1.1
============================

This is a parts pack for Kerbal Space Program v0.25, providing a new stockalike spaceplane fuselage system that is designed for hauling 2.5m parts

============
INSTALLATION
============

To install, place the GameData folder inside your Kerbal Space Program folder. If asked to overwrite files, do so. 

=========
LICENSING
=========

The contents of this pack are distributed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).

You are free to share and adapt the materials only for non-commercial purposes and when providing appropriate attribution. Any derivatives must be distributed under the same license. 